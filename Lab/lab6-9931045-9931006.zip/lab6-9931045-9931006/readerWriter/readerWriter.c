#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>


sem_t rw_mutex;
sem_t mutex;
int *cnt = 0;
int numreader = 0;
#define MAX_COUNT 20
void *writer(void *wno)
{   
    *cnt = 0;
    int shmid = shmget(0x125, 10*sizeof(int), 0666 | IPC_CREAT);
    cnt = (int *)shmat(shmid, NULL, 0);
    sem_wait(&rw_mutex);
    for (int i = 1; i <= MAX_COUNT; i++)
        {
            
            *cnt=*cnt+1;
            printf("Writer %d modified cnt to %d\n",(*((int *)wno)),*cnt);
        }
    sem_post(&rw_mutex);

}
void *reader(void *rno)
{   
    
    int shmid = shmget(0x125, 10*sizeof(int), 0444 | IPC_CREAT);
    cnt = (int *)shmat(shmid, NULL, 0);
    sem_wait(&mutex);
    numreader++;
    if(numreader == 1) {
        sem_wait(&rw_mutex); 
    }
    sem_post(&mutex);
    printf("Reader %d: read cnt as %d\n",*((int *)rno),*cnt);

    sem_wait(&mutex);
    numreader--;
    if(numreader == 0) {
        sem_post(&rw_mutex); 
    }
    sem_post(&mutex);
}

int main()
{   
    int shmid = shmget(0x125, 10 * sizeof(int), 0666 | IPC_CREAT);
    cnt = (int *)shmat(shmid, NULL, 0);
    pthread_t read[10],write[5];
    sem_init(&mutex,0,1);
    sem_init(&rw_mutex,0,1);

    int a[10] = {1,2,3,4,5};

    for(int i = 0; i < 5; i++) {
        pthread_create(&read[i], NULL, (void *)reader, (void *)&a[i]);
    }
    for(int i = 0; i < 1; i++) {
        pthread_create(&write[i], NULL, (void *)writer, (void *)&a[i]);
    }

    for(int i = 0; i < 5; i++) {
        pthread_join(read[i], NULL);
    }
    for(int i = 0; i < 1; i++) {
        pthread_join(write[i], NULL);
    }

    sem_destroy(&mutex);
    sem_destroy(&rw_mutex);

    return 0;
    
}
