#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>


char message[13] = "SaaLaaM";
#define READ_END 0
#define WRITE_END 1

int main(){
    int pipefd1[2];
    int pipefd2[2];

    pid_t pid;

    if(pipe(pipefd1) == -1){   
        perror("pipe1 error");
        exit(EXIT_FAILURE);
    }

    if(pipe(pipefd2) == -1){   
        perror("pipe2 error");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if(pid == -1){   
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    //parent
    if (pid != 0) {  

        close(pipefd1[READ_END]);

       
        close(pipefd2[WRITE_END]);

        printf("%s\n", message);

        write(pipefd1[WRITE_END], message, sizeof(message));       
        close(pipefd1[WRITE_END]);   

	wait(NULL);

        read(pipefd2[READ_END], message, sizeof(message));
        close(pipefd2[READ_END]);

        printf("changed massage is: %s\n", message);

    }//child
    else {
        close(pipefd1[WRITE_END]);
        close(pipefd2[READ_END]);


        char response[strlen(message)];

        read(pipefd1[READ_END], response, sizeof(response));
        close(pipefd1[0]);

        for(int i=0; i < strlen(response) ; i++){
            if (islower(response[i])) {
               response[i]=toupper(response[i]);
               }
            else{
              response[i] = tolower(response[i]);
              }  
        }

        write(pipefd2[WRITE_END], response, sizeof(response));
        close(pipefd2[WRITE_END]);  
        }
    return 0;
}
